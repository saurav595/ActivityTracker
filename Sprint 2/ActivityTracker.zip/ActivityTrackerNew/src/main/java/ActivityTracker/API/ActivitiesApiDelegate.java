package ActivityTracker.API;

import ActivityTracker.model.Activity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

/**
 * A delegate to be called by the {@link ActivitiesApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-07-26T23:58:39.816700-04:00[America/Toronto]")

public interface ActivitiesApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * GET /activities/{date} : Find activities summary by date
     * Returns activities summary
     *
     * @param date date of record (required)
     * @return successful operation (status code 200)
     *         or Invalid date supplied (status code 400)
     * @see ActivitiesApi#getActivitiesByDate
     */
    default ResponseEntity<List<Activity>> getActivitiesByDate(String date) {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"duration\" : 5.637376656633329, \"distance\" : 2.3021358869347655, \"segmentID\" : 6, \"summaryID\" : 1, \"placeTypeID\" : 5, \"startTime\" : \"startTime\", \"endTime\" : \"endTime\", \"calories\" : 7.061401241503109, \"activityType\" : \"activityType\", \"steps\" : 9, \"activityTypeID\" : 0 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /activities : obtains all activities
     * gets all the activities
     *
     * @return Returned all activities (status code 200)
     *         or Did not work. (status code 400)
     * @see ActivitiesApi#getAllActivities
     */
    default ResponseEntity<List<Activity>> getAllActivities() {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"duration\" : 5.637376656633329, \"distance\" : 2.3021358869347655, \"segmentID\" : 6, \"summaryID\" : 1, \"placeTypeID\" : 5, \"startTime\" : \"startTime\", \"endTime\" : \"endTime\", \"calories\" : 7.061401241503109, \"activityType\" : \"activityType\", \"steps\" : 9, \"activityTypeID\" : 0 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
