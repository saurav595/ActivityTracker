package ActivityTracker.API;

import ActivityTracker.DAO.PlacesDao;
import ActivityTracker.DAO.SegmentTypesDao;
import ActivityTracker.model.Places;
import ActivityTracker.model.SegmentTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class SegmentTypesApiDelegateImpl implements SegmentTypesApiDelegate{

    @Override
    public ResponseEntity<List<SegmentTypes>> getAllSegmentTypes() {
        SegmentTypesDao test = new SegmentTypesDao();
        ArrayList<SegmentTypes> segTypes = null;
        try {
            segTypes = test.getAllSegmentTypes();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(segTypes);
    }
}
