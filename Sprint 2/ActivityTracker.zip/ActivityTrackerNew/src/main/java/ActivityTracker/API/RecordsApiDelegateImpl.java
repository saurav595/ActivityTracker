package ActivityTracker.API;

import ActivityTracker.model.Record;
import ActivityTracker.DAO.RecordDao;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class RecordsApiDelegateImpl implements RecordsApiDelegate {

    @Override
    public ResponseEntity<List<Record>> getAllRecords() {
        RecordDao test = new RecordDao();
        ArrayList<Record> records = null;
        try {
            records = test.getAllRecords();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(records);
    }

    @Override
    public ResponseEntity<List<Record>> getRecordByDate(String date) {
        return RecordsApiDelegate.super.getRecordByDate(date);
    }
}
