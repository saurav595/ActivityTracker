package ActivityTracker.API;

import ActivityTracker.DAO.ActivityDao;
import ActivityTracker.DAO.PlacesDao;
import ActivityTracker.model.Activity;
import ActivityTracker.model.Places;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ActivityApiDelegateImpl implements ActivitiesApiDelegate {

    @Override
    public ResponseEntity<List<Activity>> getAllActivities() {
        ActivityDao test = new ActivityDao();
        ArrayList<Activity> activities = null;
        try {
            activities = test.getAllActivity();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(activities);
    }

}
