package ActivityTracker.API;

import ActivityTracker.DAO.PlacesDao;
import ActivityTracker.DAO.RecordDao;
import ActivityTracker.model.Places;
import ActivityTracker.model.Record;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class PlacesApiDelegateImpl implements PlacesApiDelegate {

    @Override
    public ResponseEntity<List<Places>> getAllPlaces() {
        PlacesDao test = new PlacesDao();
        ArrayList<Places> places = null;
        try {
            places = test.getAllPlaces();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return ResponseEntity.ok(places);
    }
}
