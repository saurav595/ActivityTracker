package ActivityTracker.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * This is the places model
 */
@ApiModel(description = "This is the places model")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-07-26T23:58:39.816700-04:00[America/Toronto]")

public class Places   {
  @JsonProperty("placeTypeID")
  private Integer placeTypeID;

  @JsonProperty("segmentID")
  private Integer segmentID;

  @JsonProperty("placeID")
  private Integer placeID;

  @JsonProperty("name")
  private String name;

  @JsonProperty("type")
  private String type;

  public Places placeTypeID(Integer placeTypeID) {
    this.placeTypeID = placeTypeID;
    return this;
  }

  /**
   * Get placeTypeID
   * @return placeTypeID
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getPlaceTypeID() {
    return placeTypeID;
  }

  public void setPlaceTypeID(Integer placeTypeID) {
    this.placeTypeID = placeTypeID;
  }

  public Places segmentID(Integer segmentID) {
    this.segmentID = segmentID;
    return this;
  }

  /**
   * Get segmentID
   * @return segmentID
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getSegmentID() {
    return segmentID;
  }

  public void setSegmentID(Integer segmentID) {
    this.segmentID = segmentID;
  }

  public Places placeID(Integer placeID) {
    this.placeID = placeID;
    return this;
  }

  /**
   * Get placeID
   * @return placeID
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getPlaceID() {
    return placeID;
  }

  public void setPlaceID(Integer placeID) {
    this.placeID = placeID;
  }

  public Places name(String name) {
    this.name = name;
    return this;
  }

  /**
   * Get name
   * @return name
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Places type(String type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Places places = (Places) o;
    return Objects.equals(this.placeTypeID, places.placeTypeID) &&
        Objects.equals(this.segmentID, places.segmentID) &&
        Objects.equals(this.placeID, places.placeID) &&
        Objects.equals(this.name, places.name) &&
        Objects.equals(this.type, places.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(placeTypeID, segmentID, placeID, name, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Places {\n");
    
    sb.append("    placeTypeID: ").append(toIndentedString(placeTypeID)).append("\n");
    sb.append("    segmentID: ").append(toIndentedString(segmentID)).append("\n");
    sb.append("    placeID: ").append(toIndentedString(placeID)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

