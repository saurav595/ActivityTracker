package ActivityTracker.DAO;

import ActivityTracker.model.Places;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PlacesDao {
    protected ConnManager connectionManager;
    private static PlacesDao instance = null;
    public PlacesDao() {
        connectionManager = new ConnManager();
    }
    public static PlacesDao getInstance() {
        if(instance == null) {
            instance = new PlacesDao();
        }
        return instance;
    }

    public Places create(Places places) throws SQLException {
        String insertPlace = "INSERT INTO Place(SegmentID, PlaceID, Name, Type) VALUES" +
                "(?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertPlace);
            insertStmt.setInt(1, places.getSegmentID());
            insertStmt.setInt(2, places.getPlaceID());
            insertStmt.setString(3, places.getName());
            insertStmt.setString(4, places.getType());
            insertStmt.executeUpdate();
            return places;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<Places> getAllPlaces() throws SQLException {
        String getPlace = "SELECT * FROM Place;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet result = null;
        ArrayList<Places> pList = new ArrayList<>();
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(getPlace);
            result = selectStmt.executeQuery();

            while (result.next()) {
                int placeTypeId = result.getInt("placetypeID");
                int segmentId = result.getInt("sid");
                int placeId = result.getInt("placeID");
                String name = result.getString("name");
                String type = result.getString("placeType");
                Places place = new Places();
                place.setSegmentID(segmentId);
                place.setPlaceID(placeTypeId);
                place.setName(name);
                place.setType(type);
                place.setPlaceID(placeId);
                pList.add(place);
            }
            return pList;

        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }
}
