package ActivityTracker.DAO;

import ActivityTracker.model.Activity;
import org.apache.coyote.ActionCode;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;

public class ActivityDao {
    protected ConnManager connectionManager;
    private static ActivityDao instance = null;
    public ActivityDao() {
        connectionManager = new ConnManager();
    }
    public static ActivityDao getInstance() {
        if(instance == null) {
            instance = new ActivityDao();
        }
        return instance;
    }

    public Activity create(Activity activity) throws SQLException {
        String insertActivity = "";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        if (activity.getSummaryID() == 0) {
            if (activity.getActivityType().toLowerCase() == "walking" || activity.getActivityType().toLowerCase() == "running") {
                insertActivity = "INSERT INTO Values(SummaryId, StartTime, EndTime, Activity, Duration, Distance, Calories, Steps)" +
                        "VALUES(?,?,?,?,?,?,?,?);";
                try {

                    connection = connectionManager.getConnection();
                    insertStmt = connection.prepareStatement(insertActivity);
                    insertStmt.setInt(1, activity.getSummaryID());
                    insertStmt.setString(2, activity.getStartTime());
                    insertStmt.setString(3, activity.getEndTime());
                    insertStmt.setString(4, activity.getActivityType());
                    insertStmt.setBigDecimal(5, activity.getDuration());
                    insertStmt.setBigDecimal(6, activity.getDistance());
                    insertStmt.setBigDecimal(7, activity.getCalories());
                    insertStmt.setInt(8, activity.getSteps());
                    insertStmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw e;
                }
            } else if (activity.getActivityType().toLowerCase() == "cycling") {
                insertActivity = "INSERT INTO Values(SummaryId, StartTime, EndTime, Activity, Duration, Distance, Calories)" +
                        "VALUES(?,?,?,?,?,?,?);";
                try {
                    connection = connectionManager.getConnection();
                    insertStmt = connection.prepareStatement(insertActivity);
                    insertStmt.setInt(1, activity.getSummaryID());
                    insertStmt.setString(2, activity.getStartTime());
                    insertStmt.setString(3, activity.getEndTime());
                    insertStmt.setString(4, activity.getActivityType());
                    insertStmt.setBigDecimal(5, activity.getDuration());
                    insertStmt.setBigDecimal(6, activity.getDistance());
                    insertStmt.setBigDecimal(7, activity.getCalories());
                    insertStmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw e;
                }
            } else {
                insertActivity = "INSERT INTO Values(SummaryId, StartTime, EndTime, Activity, Duration, Distance)" +
                        "VALUES(?,?,?,?,?,?);";
                try {
                    connection = connectionManager.getConnection();
                    insertStmt = connection.prepareStatement(insertActivity);
                    insertStmt.setInt(1, activity.getSummaryID());
                    insertStmt.setString(2, activity.getStartTime());
                    insertStmt.setString(3, activity.getEndTime());
                    insertStmt.setString(4, activity.getActivityType());
                    insertStmt.setBigDecimal(5, activity.getDuration());
                    insertStmt.setBigDecimal(6, activity.getDistance());
                    insertStmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw e;
                }
            }
        } else if (activity.getPlaceTypeID() != 0) {
            if (activity.getActivityType().toLowerCase() == "walking" || activity.getActivityType().toLowerCase() == "running") {
                insertActivity = "INSERT INTO Values(PlaceTypeId, StartTime, EndTime, Activity, Duration, Distance, Calories, Steps)" +
                        "VALUES(?,?,?,?,?,?,?,?);";
                try {

                    connection = connectionManager.getConnection();
                    insertStmt = connection.prepareStatement(insertActivity);
                    insertStmt.setInt(1, activity.getPlaceTypeID());
                    insertStmt.setString(2, activity.getStartTime());
                    insertStmt.setString(3, activity.getEndTime());
                    insertStmt.setString(4, activity.getActivityType());
                    insertStmt.setBigDecimal(5, activity.getDuration());
                    insertStmt.setBigDecimal(6, activity.getDistance());
                    insertStmt.setBigDecimal(7, activity.getCalories());
                    insertStmt.setInt(8, activity.getSteps());
                    insertStmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw e;
                }
            } else if (activity.getActivityType().toLowerCase() == "cycling") {
                insertActivity = "INSERT INTO Values(PlaceTypeId, StartTime, EndTime, Activity, Duration, Distance, Calories)" +
                        "VALUES(?,?,?,?,?,?,?);";
                try {
                    connection = connectionManager.getConnection();
                    insertStmt = connection.prepareStatement(insertActivity);
                    insertStmt.setInt(1, activity.getPlaceTypeID());
                    insertStmt.setString(2, activity.getStartTime());
                    insertStmt.setString(3, activity.getEndTime());
                    insertStmt.setString(4, activity.getActivityType());
                    insertStmt.setBigDecimal(5, activity.getDuration());
                    insertStmt.setBigDecimal(6, activity.getDistance());
                    insertStmt.setBigDecimal(7, activity.getCalories());
                    insertStmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw e;
                }
            } else {
                insertActivity = "INSERT INTO Values(PlaceTypeId, StartTime, EndTime, Activity, Duration, Distance)" +
                        "VALUES(?,?,?,?,?,?);";
                try {
                    connection = connectionManager.getConnection();
                    insertStmt = connection.prepareStatement(insertActivity);
                    insertStmt.setInt(1, activity.getPlaceTypeID());
                    insertStmt.setString(2, activity.getStartTime());
                    insertStmt.setString(3, activity.getEndTime());
                    insertStmt.setString(4, activity.getActivityType());
                    insertStmt.setBigDecimal(5, activity.getDuration());
                    insertStmt.setBigDecimal(6, activity.getDistance());
                    insertStmt.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    throw e;
                }
            }

        }
        return activity;
    }

    public ArrayList<Activity> getAllActivity() throws SQLException {
        String getActivity = "SELECT * FROM Activity;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet result = null;
        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(getActivity);
            result = selectStmt.executeQuery();
            ArrayList<Activity> aList = new ArrayList<Activity>();

            while(result.next()) {
                int activityTypeId = result.getInt("activityID");
                int segmentId = result.getInt("sid");
                int summaryId = result.getInt("summaryID");
                int placeTypeId = result.getInt("placetypeID");
                String startTime = result.getString("startTime");
                String endTime = result.getString("endTime");
                BigDecimal duration = result.getBigDecimal("duration");
                BigDecimal distance = result.getBigDecimal("distance");
                BigDecimal calories = result.getBigDecimal("calories");
                int steps = result.getInt("steps");
                Activity a = new Activity();
                a.setActivityTypeID(activityTypeId);
                a.setSegmentID(segmentId);
                a.setSummaryID(summaryId);
                a.setPlaceTypeID(placeTypeId);
                a.setStartTime(startTime);
                a.setEndTime(endTime);
                a.setDuration(duration);
                a.setDistance(distance);
                a.setCalories(calories);
                a.setSteps(steps);
                aList.add(a);
            }
            return aList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }
    }
}
