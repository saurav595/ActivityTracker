package ActivityTracker.DAO;

import ActivityTracker.DAO.ConnManager;
import ActivityTracker.model.SegmentTypes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SegmentTypesDao {
    protected ConnManager connectionManager;
    private static SegmentTypesDao instance = null;
    public SegmentTypesDao() {
        connectionManager = new ConnManager();
    }
    public static SegmentTypesDao getInstance() {
        if(instance == null) {
            instance = new SegmentTypesDao();
        }
        return instance;
    }

    public SegmentTypes create(SegmentTypes segmentType) throws SQLException {
        String insertSegmentType = "INSERT INTO SegmentTypes(Date, Type, StartTime, EndTime, LastUpdate) " +
                "VALUES(?,?,?,?,?);";
        Connection connection = null;
        PreparedStatement insertStmt = null;
        try {
            connection = connectionManager.getConnection();
            insertStmt = connection.prepareStatement(insertSegmentType);
            insertStmt.setString(1, segmentType.getDate());
            insertStmt.setString(2, segmentType.getType());
            insertStmt.setString(3, segmentType.getStartTime());
            insertStmt.setString(4, segmentType.getEndTime());
            insertStmt.setString(5, segmentType.getLastupdated());
            insertStmt.executeUpdate();
            return segmentType;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (insertStmt != null) {
                insertStmt.close();
            }
        }
    }

    public ArrayList<SegmentTypes> getAllSegmentTypes() throws SQLException {
        String getST = "SELECT * FROM SegmentTypes;";
        Connection connection = null;
        PreparedStatement selectStmt = null;
        ResultSet result = null;

        try {
            connection = connectionManager.getConnection();
            selectStmt = connection.prepareStatement(getST);
            result = selectStmt.executeQuery();
            ArrayList<SegmentTypes> sTList = new ArrayList<SegmentTypes>();
            while (result.next()) {
                int segmentID = result.getInt("segmentID");
                String type = result.getString("segmentType");
                String startTime = result.getString("startTime");
                String endTime = result.getString("endTime");
                String lastUpdate = result.getString("LastUpdate");
                SegmentTypes s = new SegmentTypes();
                s.setSegmentID(segmentID);
                s.setType(type);
                s.setStartTime(startTime);
                s.setEndTime(endTime);
                s.setLastupdated(lastUpdate);
                sTList.add(s);
            }
            return sTList;
        } catch (SQLException e) {
            e.printStackTrace();
            throw e;
        }

    }
}
