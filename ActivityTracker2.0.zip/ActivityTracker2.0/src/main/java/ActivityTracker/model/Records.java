package ActivityTracker.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import org.openapitools.jackson.nullable.JsonNullable;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * This is the records model
 */
@ApiModel(description = "This is the records model")
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T16:23:10.166876-04:00[America/Toronto]")

public class Records   {
  @JsonProperty("date")
  private LocalDate date;

  @JsonProperty("calorieIdle")
  private Integer calorieIdle;

  @JsonProperty("lastupdated")
  private OffsetDateTime lastupdated;

  public Records date(LocalDate date) {
    this.date = date;
    return this;
  }

  /**
   * Get date
   * @return date
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public LocalDate getDate() {
    return date;
  }

  public void setDate(LocalDate date) {
    this.date = date;
  }

  public Records calorieIdle(Integer calorieIdle) {
    this.calorieIdle = calorieIdle;
    return this;
  }

  /**
   * Get calorieIdle
   * @return calorieIdle
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getCalorieIdle() {
    return calorieIdle;
  }

  public void setCalorieIdle(Integer calorieIdle) {
    this.calorieIdle = calorieIdle;
  }

  public Records lastupdated(OffsetDateTime lastupdated) {
    this.lastupdated = lastupdated;
    return this;
  }

  /**
   * Get lastupdated
   * @return lastupdated
   */
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public OffsetDateTime getLastupdated() {
    return lastupdated;
  }

  public void setLastupdated(OffsetDateTime lastupdated) {
    this.lastupdated = lastupdated;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Records records = (Records) o;
    return Objects.equals(this.date, records.date) &&
            Objects.equals(this.calorieIdle, records.calorieIdle) &&
            Objects.equals(this.lastupdated, records.lastupdated);
  }

  @Override
  public int hashCode() {
    return Objects.hash(date, calorieIdle, lastupdated);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Records {\n");

    sb.append("    date: ").append(toIndentedString(date)).append("\n");
    sb.append("    calorieIdle: ").append(toIndentedString(calorieIdle)).append("\n");
    sb.append("    lastupdated: ").append(toIndentedString(lastupdated)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

