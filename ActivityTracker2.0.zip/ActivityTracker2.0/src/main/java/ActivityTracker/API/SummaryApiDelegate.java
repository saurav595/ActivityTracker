package ActivityTracker.API;

import ActivityTracker.model.Summary;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

/**
 * A delegate to be called by the {@link SummaryApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public interface SummaryApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * POST /summary : creates a summary
     *
     * @param summary  (required)
     * @return Successfully created. (status code 200)
     *         or Did not work. (status code 400)
     * @see SummaryApi#createSummary
     */
    default ResponseEntity<Void> createSummary(Summary summary) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /summary : obtains all summary
     * gets all the summary
     *
     * @return Returned all summary. (status code 200)
     *         or Did not work. (status code 400)
     * @see SummaryApi#getAllSummary
     */
    default ResponseEntity<List<Summary>> getAllSummary() {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"date\" : \"2000-01-23\", \"summaryId\" : 0 }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
