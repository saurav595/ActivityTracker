package ActivityTracker.API;

import ActivityTracker.model.ActivitySummary;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class ActivitySummaryApiDelegateImpl implements ActivitySummaryApiDelegate{

    @Override
    public ResponseEntity<Void> createActivitySummary(ActivitySummary activitySummary) {
        return ActivitySummaryApiDelegate.super.createActivitySummary(activitySummary);
    }

    @Override
    public ResponseEntity<List<ActivitySummary>> getAllActivitiesByDate(String date) {
        return ActivitySummaryApiDelegate.super.getAllActivitiesByDate(date);
    }

    @Override
    public ResponseEntity<List<ActivitySummary>> getAllActivitySummary() {
        return ActivitySummaryApiDelegate.super.getAllActivitySummary();
    }

    @Override
    public ResponseEntity<List<ActivitySummary>> getSpecificActivitySummaryByDate(String date, String activity) {
        return ActivitySummaryApiDelegate.super.getSpecificActivitySummaryByDate(date, activity);
    }
}
