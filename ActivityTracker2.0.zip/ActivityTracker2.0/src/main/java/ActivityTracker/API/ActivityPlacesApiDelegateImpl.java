package ActivityTracker.API;

import ActivityTracker.model.ActivityPlaces;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class ActivityPlacesApiDelegateImpl implements ActivityPlacesApiDelegate{

    @Override
    public ResponseEntity<Void> createActivityPlace(ActivityPlaces activityPlaces) {
        return ActivityPlacesApiDelegate.super.createActivityPlace(activityPlaces);
    }

    @Override
    public ResponseEntity<List<ActivityPlaces>> getAllActivityPlaces() {
        return ActivityPlacesApiDelegate.super.getAllActivityPlaces();
    }
}
