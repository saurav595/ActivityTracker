package ActivityTracker.API;

import ActivityTracker.model.ActivitySegmentTypes;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class ActivitySegmentTypesApiDelegateImpl implements ActivitySegmentTypesApiDelegate{

    @Override
    public ResponseEntity<Void> createActivitySegmentType(ActivitySegmentTypes activitySegmentTypes) {
        return ActivitySegmentTypesApiDelegate.super.createActivitySegmentType(activitySegmentTypes);
    }

    @Override
    public ResponseEntity<List<ActivitySegmentTypes>> getAllActivitySegmentTypes() {
        return ActivitySegmentTypesApiDelegate.super.getAllActivitySegmentTypes();
    }
}
