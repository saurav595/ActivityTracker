package ActivityTracker.API;

import ActivityTracker.model.SegmentTypes;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.List;
import java.util.Optional;

/**
 * A delegate to be called by the {@link SegmentTypesApiController}}.
 * Implement this interface with a {@link org.springframework.stereotype.Service} annotated class.
 */
@javax.annotation.Generated(value = "org.openapitools.codegen.languages.SpringCodegen", date = "2021-08-05T15:58:24.603184-04:00[America/Toronto]")

public interface SegmentTypesApiDelegate {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    /**
     * POST /segmentTypes : creates a segment type
     *
     * @param segmentTypes  (required)
     * @return Successfully created. (status code 200)
     *         or Did not work. (status code 400)
     * @see SegmentTypesApi#createSegmentTypes
     */
    default ResponseEntity<Void> createSegmentTypes(SegmentTypes segmentTypes) {
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

    /**
     * GET /segmentTypes : obtains all segmentTypes
     * gets all segmentTypes
     *
     * @return Returned all segment types. (status code 200)
     *         or Did not work. (status code 400)
     * @see SegmentTypesApi#getAllSegmentTypes
     */
    default ResponseEntity<List<SegmentTypes>> getAllSegmentTypes() {
        getRequest().ifPresent(request -> {
            for (MediaType mediaType: MediaType.parseMediaTypes(request.getHeader("Accept"))) {
                if (mediaType.isCompatibleWith(MediaType.valueOf("application/json"))) {
                    String exampleString = "{ \"date\" : \"2000-01-23\", \"segmentId\" : 0, \"lastUpdate\" : \"2000-01-23T04:56:07.000+00:00\", \"startTime\" : \"2000-01-23T04:56:07.000+00:00\", \"endTime\" : \"2000-01-23T04:56:07.000+00:00\", \"segmentType\" : \"segmentType\" }";
                    ApiUtil.setExampleResponse(request, "application/json", exampleString);
                    break;
                }
            }
        });
        return new ResponseEntity<>(HttpStatus.NOT_IMPLEMENTED);

    }

}
