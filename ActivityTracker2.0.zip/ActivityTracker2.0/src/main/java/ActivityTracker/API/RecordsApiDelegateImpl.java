package ActivityTracker.API;

import ActivityTracker.model.Records;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class RecordsApiDelegateImpl implements RecordsApiDelegate {

    @Override
    public ResponseEntity<Void> createRecord(Records records) {
        return RecordsApiDelegate.super.createRecord(records);
    }

    @Override
    public ResponseEntity<Void> deleteRecord(String date) {
        return RecordsApiDelegate.super.deleteRecord(date);
    }

    @Override
    public ResponseEntity<List<Records>> getAllRecords() {
        return RecordsApiDelegate.super.getAllRecords();
    }
}
