package ActivityTracker.API;

import ActivityTracker.model.Place;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class PlacesApiDelegateImpl implements PlacesApiDelegate {

    @Override
    public ResponseEntity<Void> createPlace(Place place) {
        return PlacesApiDelegate.super.createPlace(place);
    }

    @Override
    public ResponseEntity<List<Place>> getAllPlaces() {
        return PlacesApiDelegate.super.getAllPlaces();
    }
}
