package ActivityTracker.API;

import ActivityTracker.model.SegmentTypes;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class SegmentTypesApiDelegateImpl implements SegmentTypesApiDelegate{

    @Override
    public ResponseEntity<Void> createSegmentTypes(SegmentTypes segmentTypes) {
        return SegmentTypesApiDelegate.super.createSegmentTypes(segmentTypes);
    }

    @Override
    public ResponseEntity<List<SegmentTypes>> getAllSegmentTypes() {
        return SegmentTypesApiDelegate.super.getAllSegmentTypes();
    }

}
