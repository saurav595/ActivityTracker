package ActivityTracker.API;

import ActivityTracker.model.Summary;
import org.springframework.http.ResponseEntity;

import java.util.List;

public class SummaryApiDelegateImpl implements SummaryApiDelegate {

    @Override
    public ResponseEntity<Void> createSummary(Summary summary) {
        return SummaryApiDelegate.super.createSummary(summary);
    }

    @Override
    public ResponseEntity<List<Summary>> getAllSummary() {
        return SummaryApiDelegate.super.getAllSummary();
    }
}
