var matrix = [[0,0,0,4],[0,0,0,0],[4,0,0,0],[0,0,0,0]]
var packages = [{
"name": " ActivityTracker.DAO", "color": " #3182bd"
}
,{
"name": " ActivityTracker", "color": " #6baed6"
}
,{
"name": " ActivityTracker.API", "color": " #9ecae1"
}
,{
"name": " ActivityTracker.model", "color": " #c6dbef"
}
];
